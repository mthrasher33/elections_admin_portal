// config/database.js
module.exports = {
    'connection': {
        'host': 'elections.c44css47zkdo.us-west-2.rds.amazonaws.com',
        'user': 'admin',
        'password': '35THmeridian',
        'database': 'election_results',
        connectionLimit: 10

    },
	'database': 'election_results',
    'users_table': 'users'
};
//module.exports = configDB;